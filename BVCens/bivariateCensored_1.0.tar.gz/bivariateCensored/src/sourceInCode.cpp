//
//  sourceInCode.h
//  
//
//  Created by Cliff Anderson Bergman on 8/29/15.
//
//

#ifndef _sourceInCode_h
#define _sourceInCode_h

#include "sourceCode/bivariateNPMLE.h"
#include "sourceCode/basicUtilities.cpp"
#include "sourceCode/bivariateNPMLE.cpp"


#endif
